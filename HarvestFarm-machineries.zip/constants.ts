import { Product, Category, Testimonial } from './types';

export const PHONE_NUMBER = "+254780037335";
export const WHATSAPP_LINK = `https://wa.me/254780037335`;
export const LOCATION_LINK = "https://maps.google.com/?q=Nakuru+Kenya+Harvest+Farm+Machinery";

export const CATEGORIES: Category[] = [
  { id: 'posho-mills', name: 'Posho Mills', image: 'https://images.unsplash.com/photo-1530507629858-e4977d30e9e0?auto=format&fit=crop&q=80&w=600' },
  { id: 'hullers', name: 'Hullers', image: 'https://images.unsplash.com/photo-1622383563227-0440114a8474?auto=format&fit=crop&q=80&w=600' },
  { id: 'chopper-mills', name: 'Chopper Mills', image: 'https://images.unsplash.com/photo-1596733430282-743a75591789?auto=format&fit=crop&q=80&w=600' },
  { id: 'roller-mills', name: 'Roller Mills', image: 'https://images.unsplash.com/photo-1627920769843-2d2426372559?auto=format&fit=crop&q=80&w=600' },
  { id: 'maize-shellers', name: 'Maize Shellers', image: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182?auto=format&fit=crop&q=80&w=600' },
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Standard Combined Posho Mill',
    category: 'Posho Mills',
    price: 95000,
    image: 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&q=80&w=800',
    description: 'Reliable combined posho mill that hullers and mills in one process. Engineered for long-term farm success.',
    specs: {
      'Power Source': '10HP Diesel or 7.5HP Electric',
      'Capacity': '3-5 Bags/Hour',
      'Mounting': 'Heavy Duty Steel Frame',
      'Warranty': '1 Year Full Support'
    },
    isBestSeller: true
  },
  {
    id: '2',
    name: 'Advanced Coffee Huller',
    category: 'Hullers',
    price: 125000,
    image: 'https://images.unsplash.com/photo-1622383563227-0440114a8474?auto=format&fit=crop&q=80&w=800',
    description: 'Precision engineered huller for efficient coffee and cereal processing. Minimizes grain breakage.',
    specs: {
      'Motor': '5HP Electric',
      'Efficiency': '98% Recovery Rate',
      'Material': 'Industrial Grade Iron',
      'Warranty': '1 Year Full Support'
    },
    isBestSeller: true
  },
  {
    id: '3',
    name: 'Industrial Chopper Mill',
    category: 'Chopper Mills',
    price: 65000,
    image: 'https://images.unsplash.com/photo-1592982537447-6f2a6a0c8019?auto=format&fit=crop&q=80&w=800',
    description: 'Powerful chopper mill for silage preparation and animal feed processing. High-speed rotation for fine input.',
    specs: {
      'Engine': '8HP Petrol / Diesel',
      'Function': 'Dual Chopping/Grinding',
      'Portability': 'Mobile with Wheels',
      'Warranty': '1 Year Full Support'
    }
  },
  {
    id: '4',
    name: 'Grade 1 Roller Mill',
    category: 'Roller Mills',
    price: 185000,
    image: 'https://images.unsplash.com/photo-1627920769843-2d2426372559?auto=format&fit=crop&q=80&w=800',
    description: 'Premium roller mill for producing high-quality sifter-grade flour. Used by commercial millers across Kenya.',
    specs: {
      'Motor': '10HP 3-Phase',
      'Inlet': 'Auto-Feeding Hopper',
      'Sifter': 'Built-in Fine Sifter',
      'Warranty': '1 Year Full Support'
    }
  },
  {
    id: '5',
    name: 'Heavy Duty Maize Sheller',
    category: 'Maize Shellers',
    price: 45000,
    image: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182?auto=format&fit=crop&q=80&w=800',
    description: 'Eases the post-harvest process by shelling maize quickly with minimal grain loss. Built to last.',
    specs: {
      'Output': '15-20 Bags/Hour',
      'Power': '7.5HP Engine Compatible',
      'Material': 'Reinforced Steel Body',
      'Warranty': '1 Year Full Support'
    }
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'John Kamau',
    location: 'Kericho',
    text: 'I bought the 10HP Posho Mill. The installation team was very professional. Business is good!',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200'
  },
  {
    id: '2',
    name: 'Mary Wanjiku',
    location: 'Nyandarua',
    text: 'The chopper mill has saved me so much time. Feeding my cows is now easy. Asante sana Harvest Farm.',
    image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&q=80&w=200'
  },
  {
    id: '3',
    name: 'Peter Omondi',
    location: 'Kisumu',
    text: 'Legit guys. I paid on delivery after testing the machine. Highly recommend for any farmer.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200'
  }
];