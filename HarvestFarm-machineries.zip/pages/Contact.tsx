import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { PHONE_NUMBER, WHATSAPP_LINK } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-harvest-brown text-white py-16 px-4 text-center">
        <h1 className="text-5xl font-black tracking-tight uppercase">Get in Touch</h1>
        <p className="text-harvest-gold mt-2 font-bold tracking-[0.2em]">Contact Harvest Farm Machineries</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <h2 className="text-3xl font-black mb-8 text-harvest-brown tracking-tight">Our Showroom</h2>
            <p className="text-gray-600 mb-10 text-lg leading-relaxed font-medium">
              Join the hundreds of farmers who have powered their success with a Harvest machine. 
              Founded by Ian Wambugu Ochieng Sitati, we offer expert advice on all agricultural equipment.
            </p>

            <div className="space-y-10">
              <div className="flex items-start gap-6 group">
                <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green group-hover:scale-110 transition-transform">
                  <Phone size={32} />
                </div>
                <div>
                  <h3 className="font-black text-xl text-harvest-brown">Call or WhatsApp</h3>
                  <p className="text-gray-500 mb-1 font-semibold uppercase text-xs tracking-wider">Expert Advice Line</p>
                  <a href={`tel:${PHONE_NUMBER}`} className="text-harvest-green font-black text-2xl hover:underline">{PHONE_NUMBER}</a>
                </div>
              </div>

              <div className="flex items-start gap-6 group">
                <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green group-hover:scale-110 transition-transform">
                  <MapPin size={32} />
                </div>
                <div>
                  <h3 className="font-black text-xl text-harvest-brown">Our Location</h3>
                  <p className="text-gray-600 font-medium leading-relaxed">
                    Main Showroom, Nakuru CBD<br/>
                    Open to all Farmers in Kenya.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-6 group">
                <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green group-hover:scale-110 transition-transform">
                  <Mail size={32} />
                </div>
                <div>
                  <h3 className="font-black text-xl text-harvest-brown">Email Inquiries</h3>
                  <a href="mailto:sales@harvestfarm.co.ke" className="text-gray-600 font-bold hover:text-harvest-green text-lg">sales@harvestfarm.co.ke</a>
                </div>
              </div>

              <div className="flex items-start gap-6 group">
                <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green group-hover:scale-110 transition-transform">
                  <Clock size={32} />
                </div>
                <div>
                  <h3 className="font-black text-xl text-harvest-brown">Office Hours</h3>
                  <p className="text-gray-600 font-medium">Monday - Saturday: 7:30 AM - 6:00 PM</p>
                  <p className="text-harvest-brown font-bold uppercase text-xs mt-1">Closed on Sundays & Holidays</p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="block w-full bg-[#25D366] text-white text-center py-5 rounded-2xl font-black text-xl hover:bg-green-600 transition-all shadow-xl hover:-translate-y-1 uppercase tracking-widest text-sm">
                WhatsApp Live Inquiry
              </a>
            </div>
          </div>

          {/* Form & Map */}
          <div className="flex flex-col gap-10">
            <div className="bg-harvest-cream/50 p-10 rounded-[2.5rem] shadow-2xl border border-white relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-harvest-green opacity-20"></div>
              <h3 className="text-2xl font-black text-harvest-brown mb-8 uppercase tracking-tight">Send an Inquiry</h3>
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="space-y-2">
                  <label className="block text-xs font-black text-harvest-brown uppercase tracking-widest pl-1">Farmer Name</label>
                  <input type="text" className="w-full rounded-2xl border-gray-200 focus:ring-harvest-green focus:border-harvest-green py-4 px-6 font-medium shadow-sm" placeholder="John Ochieng" />
                </div>
                <div className="space-y-2">
                  <label className="block text-xs font-black text-harvest-brown uppercase tracking-widest pl-1">Mobile Contact</label>
                  <input type="tel" className="w-full rounded-2xl border-gray-200 focus:ring-harvest-green focus:border-harvest-green py-4 px-6 font-medium shadow-sm" placeholder="07XX XXX XXX" />
                </div>
                <div className="space-y-2">
                  <label className="block text-xs font-black text-harvest-brown uppercase tracking-widest pl-1">Specific Machinery Inquiry</label>
                  <textarea rows={4} className="w-full rounded-2xl border-gray-200 focus:ring-harvest-green focus:border-harvest-green py-4 px-6 font-medium shadow-sm" placeholder="Tell us about your farm and the equipment you need..."></textarea>
                </div>
                <button className="w-full bg-harvest-brown text-white font-black py-5 rounded-2xl hover:bg-brown-700 transition-all hover:scale-[1.02] active:scale-95 shadow-xl uppercase tracking-widest text-sm">
                  Send to Harvest Team
                </button>
              </form>
            </div>
            
            <div className="bg-gray-100 rounded-[2.5rem] h-80 w-full flex items-center justify-center relative overflow-hidden group shadow-2xl border-4 border-white">
               <img 
                 src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?auto=format&fit=crop&q=80&w=800" 
                 alt="Map location" 
                 className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-all duration-1000"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-harvest-brown/80 to-transparent"></div>
               <div className="relative bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-2xl text-center border border-white/50">
                 <p className="font-black text-harvest-brown uppercase tracking-tight">Main Showroom</p>
                 <p className="text-xs text-harvest-green font-bold uppercase tracking-widest mt-1">Nakuru, Kenya</p>
                 <div className="mt-4 bg-harvest-brown text-white rounded-lg py-2 px-4 text-xs font-bold transition-all hover:bg-harvest-green cursor-pointer">
                    Open Map
                 </div>
               </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
};

export default Contact;