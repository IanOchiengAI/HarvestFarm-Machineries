import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { ArrowRight, CheckCircle, Truck, Wrench, ShieldCheck } from 'lucide-react';
import { CATEGORIES, PRODUCTS, TESTIMONIALS, WHATSAPP_LINK } from '../constants';
import ProductCard from '../components/ProductCard';

const Home: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const bestSellers = PRODUCTS.filter(p => p.isBestSeller);

  return (
    <main>
      <Helmet>
        <title>Harvest Farm Machineries Nakuru | Kenya's Most Reliable Farm Equipment</title>
      </Helmet>
      {/* Hero Section */}
      <section className="relative h-[650px] bg-harvest-brown flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1625246333195-58197bd47d26?auto=format&fit=crop&q=80&w=1920" 
            alt="Kenyan farm with machinery" 
            className="w-full h-full object-cover opacity-30 scale-105 animate-pulse"
            style={{ animationDuration: '8s' }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-harvest-brown via-harvest-brown/80 to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 w-full">
          <div className="max-w-3xl text-white">
            <span className="bg-harvest-green text-white px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-[0.2em] mb-6 inline-block border border-white/20">
              Trusted Partners in Nakuru
            </span>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-[1.1]">
              Powering Kenya's <br />
              <span className="text-harvest-gold">Farms</span> with Reliability
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-10 leading-relaxed font-light opacity-90">
              Founded by Ian Wambugu Ochieng Sitati, Harvest Farm Machinery provides posho mills, shellers, and training to help you thrive.
            </p>
            <div className="flex flex-col sm:flex-row gap-5">
              <Link to="/shop" className="bg-harvest-green hover:bg-green-700 text-white px-10 py-5 rounded-xl font-black text-center transition-all hover:scale-105 shadow-xl flex items-center justify-center gap-2 uppercase tracking-widest text-sm">
                Explore Machinery <ArrowRight size={20} />
              </Link>
              <a href={WHATSAPP_LINK} className="bg-harvest-gold text-harvest-brown hover:bg-wheat-200 px-10 py-5 rounded-xl font-black text-center transition-all hover:scale-105 shadow-xl uppercase tracking-widest text-sm">
                Get Expert Advice
              </a>
            </div>
            <div className="mt-12 flex items-center gap-8 text-sm font-bold">
              <span className="flex items-center gap-2 opacity-80 transition-opacity hover:opacity-100"><CheckCircle size={18} className="text-harvest-gold" /> Nationwide Delivery</span>
              <span className="flex items-center gap-2 opacity-80 transition-opacity hover:opacity-100"><CheckCircle size={18} className="text-harvest-gold" /> Machine Training</span>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 bg-white border-b border-gray-100 relative z-20 -mt-10 max-w-6xl mx-auto rounded-2xl shadow-2xl">
        <div className="px-8 flex flex-col md:flex-row gap-8 justify-between">
            <div className="flex items-center gap-5">
              <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green shadow-inner">
                <Truck size={36} />
              </div>
              <div>
                <h3 className="font-black text-harvest-brown text-lg uppercase tracking-tight">Safe Transport</h3>
                <p className="text-gray-500 text-xs font-semibold">Reliable nationwide reach</p>
              </div>
            </div>
            <div className="h-16 w-px bg-gray-100 hidden md:block"></div>
            <div className="flex items-center gap-5">
              <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green shadow-inner">
                <Wrench size={36} />
              </div>
              <div>
                <h3 className="font-black text-harvest-brown text-lg uppercase tracking-tight">Full Training</h3>
                <p className="text-gray-500 text-xs font-semibold">Expert equipment demos</p>
              </div>
            </div>
            <div className="h-16 w-px bg-gray-100 hidden md:block"></div>
            <div className="flex items-center gap-5">
              <div className="bg-harvest-green/10 p-4 rounded-2xl text-harvest-green shadow-inner">
                <ShieldCheck size={36} />
              </div>
              <div>
                <h3 className="font-black text-harvest-brown text-lg uppercase tracking-tight">True Reliability</h3>
                <p className="text-gray-500 text-xs font-semibold">Machines as hard as you</p>
              </div>
            </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-harvest-cream/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-harvest-green font-black text-xs uppercase tracking-widest mb-2 block">Our Product Line</span>
              <h2 className="text-4xl font-black text-harvest-brown mb-2 tracking-tight">Essential Equipment</h2>
              <p className="text-gray-600 font-medium italic">Reliable solutions for small and large-scale farmers.</p>
            </div>
            <Link to="/shop" className="bg-white border-2 border-harvest-brown text-harvest-brown px-6 py-2 rounded-lg font-bold hover:bg-harvest-brown hover:text-white transition-all hidden md:block uppercase text-xs">View Full Catalog</Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CATEGORIES.map((cat) => (
              <Link to="/shop" key={cat.id} className="group relative rounded-xl overflow-hidden aspect-square shadow-md">
                <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4">
                  <span className="text-white font-bold text-lg">{cat.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-harvest-brown font-black text-xs uppercase tracking-[0.2em]">Quality Assured</span>
            <h2 className="text-4xl font-black text-harvest-brown mt-4 tracking-tight">Best Selling Machines</h2>
            <div className="w-24 h-1 bg-harvest-gold mx-auto mt-6 rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {bestSellers.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="text-center mt-16">
            <Link to="/shop" className="inline-block border-2 border-harvest-brown text-harvest-brown font-black px-10 py-4 rounded-xl hover:bg-harvest-brown hover:text-white transition-all uppercase tracking-widest text-xs shadow-lg">
              View All Equipment
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-harvest-brown text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-harvest-gold/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-harvest-green/10 rounded-full blur-3xl -ml-48 -mb-48"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <h2 className="text-4xl font-black text-center mb-16 tracking-tight">Success Stories from across <span className="text-harvest-gold">Kenya</span></h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {TESTIMONIALS.map((t) => (
              <div key={t.id} className="bg-white/5 backdrop-blur-md p-8 rounded-3xl border border-white/10 hover:border-harvest-gold/50 transition-all group">
                <div className="flex items-center gap-5 mb-6">
                  <img src={t.image} alt={t.name} className="w-16 h-16 rounded-2xl object-cover border-2 border-harvest-gold shadow-xl transition-transform group-hover:scale-110" />
                  <div>
                    <h4 className="font-bold text-lg">{t.name}</h4>
                    <span className="text-xs font-black text-harvest-gold/80 uppercase tracking-widest">{t.location}</span>
                  </div>
                </div>
                <p className="text-gray-200 leading-relaxed italic text-lg font-light opacity-90 group-hover:opacity-100">"{t.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-harvest-cream overflow-hidden border-t border-gray-100">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <div className="inline-block p-4 bg-harvest-green/10 rounded-2xl text-harvest-green mb-8">
            <ShieldCheck size={48} />
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-harvest-brown mb-8 tracking-tight">Empowering Your Farm's Success</h2>
          <p className="text-gray-600 mb-12 text-xl max-w-3xl mx-auto font-medium leading-relaxed">
            At Harvest Farm Machinery, we believe in providing not just tools, but the knowledge for farmers to thrive. 
            Join the community of successful Kenyan farmers today.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
             <a href={WHATSAPP_LINK} className="bg-harvest-green shadow-xl shadow-harvest-green/30 text-white px-12 py-5 rounded-2xl font-black hover:bg-green-700 transition-all hover:-translate-y-1 uppercase tracking-widest text-sm">
                WhatsApp Us Directly
             </a>
             <Link to="/contact" className="bg-white shadow-xl text-harvest-brown border border-gray-200 px-12 py-5 rounded-2xl font-black hover:bg-gray-50 transition-all hover:-translate-y-1 uppercase tracking-widest text-sm">
               Visit Our Showroom
             </Link>
          </div>
        </div>
      </section>
    </main>
  );
};

export default Home;