import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { PRODUCTS, WHATSAPP_LINK, PHONE_NUMBER } from '../constants';
import { Check, Phone, MessageCircle, Star, Truck } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState(PRODUCTS.find(p => p.id === id));
  
  useEffect(() => {
    setProduct(PRODUCTS.find(p => p.id === id));
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Link to="/shop" className="text-agro-green underline">Go back to shop</Link>
        </div>
      </div>
    );
  }

  const relatedProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

  // Schema.org Structured Data
  const productSchema = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": product.name,
    "image": [product.image],
    "description": product.description,
    "brand": {
      "@type": "Brand",
      "name": "Agro Farm Machineries"
    },
    "offers": {
      "@type": "Offer",
      "priceCurrency": "KES",
      "price": product.price,
      "itemCondition": "https://schema.org/NewCondition",
      "availability": "https://schema.org/InStock",
      "seller": {
        "@type": "Organization",
        "name": "Agro Farm Machineries Nakuru"
      }
    }
  };

  return (
    <div className="bg-white min-h-screen pb-16">
      <Helmet>
        <title>{product.name} | Buy in Nakuru | Agro Farm Machineries</title>
        <meta name="description" content={`Get the best price for ${product.name}. High quality ${product.category} in Nakuru, Kenya. Pay on delivery and free installation.`} />
        <script type="application/ld+json">
          {JSON.stringify(productSchema)}
        </script>
      </Helmet>
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        
        {/* Breadcrumb */}
        <div className="text-sm text-gray-500 mb-8">
          <Link to="/" className="hover:text-agro-green">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/shop" className="hover:text-agro-green">Shop</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900 font-medium">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Gallery Side */}
          <div className="space-y-4">
            <div className="bg-gray-100 rounded-2xl overflow-hidden aspect-square">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {/* Mock thumbnails */}
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-gray-100 rounded-lg aspect-square overflow-hidden cursor-pointer hover:ring-2 hover:ring-agro-green">
                   <img src={product.image} alt="Thumbnail" className="w-full h-full object-cover opacity-80 hover:opacity-100" />
                </div>
              ))}
              <div className="bg-gray-900 rounded-lg aspect-square flex items-center justify-center text-white cursor-pointer hover:bg-gray-800">
                <span className="text-xs font-bold text-center">Watch<br/>Demo<br/>Video</span>
              </div>
            </div>
          </div>

          {/* Info Side */}
          <div>
            <span className="text-agro-green font-bold text-sm tracking-wide uppercase">{product.category}</span>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">{product.name}</h1>
            
            <div className="flex items-center gap-2 mb-6">
              <div className="flex text-yellow-400">
                {[1,2,3,4,5].map(i => <Star key={i} size={16} fill="currentColor" />)}
              </div>
              <span className="text-gray-500 text-sm">(24 Customer Reviews)</span>
            </div>

            <div className="text-4xl font-bold text-gray-900 mb-6">
              KSh {product.price.toLocaleString()}
            </div>

            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              {product.description} Built for durability and high efficiency in Kenyan farming conditions.
            </p>

            <div className="space-y-3 mb-8">
              <div className="flex items-center gap-3 text-gray-700">
                <div className="bg-green-100 p-1 rounded-full"><Check size={16} className="text-agro-green" /></div>
                <span>Available in stock (Nakuru)</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="bg-green-100 p-1 rounded-full"><Check size={16} className="text-agro-green" /></div>
                <span>Pay on Delivery + Installation</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="bg-green-100 p-1 rounded-full"><Check size={16} className="text-agro-green" /></div>
                <span>1 Year Warranty</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <a 
                href={`${WHATSAPP_LINK}?text=Hi, I am interested in ${product.name}`} 
                target="_blank" 
                rel="noreferrer"
                className="flex-1 bg-agro-green text-white py-4 px-6 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-green-700 transition-colors shadow-lg shadow-green-900/20"
              >
                <MessageCircle /> Order on WhatsApp
              </a>
              <a 
                href={`tel:${PHONE_NUMBER}`}
                className="flex-1 bg-white border-2 border-gray-200 text-gray-900 py-4 px-6 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:border-gray-900 transition-colors"
              >
                <Phone /> Call Now
              </a>
            </div>

            <div className="bg-agro-cream p-4 rounded-xl border border-orange-100">
               <div className="flex items-center gap-3 mb-2">
                 <Truck className="text-agro-orange" />
                 <span className="font-bold text-gray-900">Delivery Information</span>
               </div>
               <p className="text-sm text-gray-600">
                 We deliver within 24-48 hours nationwide. Transport cost depends on your location. 
                 Free installation included for this machine.
               </p>
            </div>
          </div>
        </div>

        {/* Specs Table */}
        <div className="mb-16">
           <h2 className="text-2xl font-bold mb-6">Technical Specifications</h2>
           <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
             <table className="w-full text-left">
               <tbody className="divide-y divide-gray-100">
                 {Object.entries(product.specs).map(([key, value], index) => (
                   <tr key={key} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                     <td className="p-4 font-semibold text-gray-700 w-1/3">{key}</td>
                     <td className="p-4 text-gray-600">{value}</td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default ProductDetail;