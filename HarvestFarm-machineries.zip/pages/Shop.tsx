import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { PRODUCTS, CATEGORIES } from '../constants';
import ProductCard from '../components/ProductCard';
import { Filter, Search, X, SlidersHorizontal } from 'lucide-react';

const Shop: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('default');
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const filteredProducts = PRODUCTS.filter(product => {
    const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    return 0; // default
  });

  const categoryNames = ['All', ...CATEGORIES.map(c => c.name)];

  return (
    <div className="bg-harvest-cream min-h-screen py-8">
      <Helmet>
        <title>Shop Farm Machinery | Posho Mills & Hullers | Harvest Farm Nakuru</title>
        <meta name="description" content="Explore our catalog of reliable farm machinery. Search for posho mills, hullers, and more. Quality equipment for Kenyan farmers." />
      </Helmet>
      
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* Sidebar / Filters */}
          <div className="w-full md:w-72 flex-shrink-0">
            <div className="bg-white p-8 rounded-3xl shadow-xl sticky top-24 border border-white">
              <div className="flex items-center gap-3 mb-8 text-harvest-brown">
                <div className="bg-harvest-gold/20 p-2 rounded-xl">
                  <SlidersHorizontal size={20} className="text-harvest-brown" />
                </div>
                <h3 className="font-black text-xl uppercase tracking-tight">Filters</h3>
              </div>
              
              {/* Category Filter */}
              <div className="mb-10">
                <h4 className="font-black mb-4 text-[10px] text-gray-400 uppercase tracking-[0.2em] flex justify-between items-center">
                  <span>Categories</span>
                  <span className="bg-gray-100 text-gray-400 px-2 py-0.5 rounded-full">{CATEGORIES.length}</span>
                </h4>
                <div className="flex flex-col gap-1.5">
                  {categoryNames.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`text-left px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
                        activeCategory === cat 
                          ? 'bg-harvest-brown text-harvest-gold shadow-lg shadow-harvest-brown/20 -translate-x-1' 
                          : 'hover:bg-harvest-cream text-gray-600 hover:text-harvest-green'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Power Source (Visual only for now) */}
              <div className="mb-8">
                <h4 className="font-black mb-4 text-[10px] text-gray-400 uppercase tracking-[0.2em]">Power Source</h4>
                <div className="space-y-3">
                  {['Diesel', 'Electric', 'Petrol'].map(source => (
                    <label key={source} className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer group">
                      <div className="w-5 h-5 border-2 border-gray-200 rounded-md group-hover:border-harvest-green transition-colors flex items-center justify-center">
                        <div className="w-2 h-2 bg-harvest-green rounded-sm opacity-0 transition-opacity"></div>
                      </div>
                      <span className="font-medium group-hover:text-harvest-brown">{source}</span>
                    </label>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
                className="w-full py-3 rounded-xl border-2 border-gray-100 text-gray-400 text-xs font-black uppercase tracking-widest hover:bg-gray-50 transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-grow">
            
            {/* Search Header */}
            <div className="bg-white p-6 rounded-3xl shadow-xl border border-white mb-8">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Search size={22} className="text-harvest-brown opacity-40" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name or keyword (e.g. 'diesel', 'milling', 'huller')..."
                  className="w-full bg-harvest-cream/50 border-2 border-transparent focus:border-harvest-green focus:bg-white rounded-2xl pl-12 pr-12 py-4 text-gray-800 font-bold placeholder:text-gray-400 focus:outline-none transition-all shadow-inner"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-harvest-brown"
                  >
                    <X size={20} />
                  </button>
                )}
              </div>
            </div>

            {/* Results Info & Sort */}
            <div className="flex flex-col lg:flex-row justify-between items-center mb-8 gap-6">
              <div className="text-center lg:text-left">
                <h1 className="text-3xl font-black text-harvest-brown tracking-tight">
                  {activeCategory === 'All' ? 'Full Catalog' : activeCategory}
                </h1>
                {searchQuery && (
                  <p className="text-sm text-gray-500 font-medium mt-1">
                    Showing results for "<span className="text-harvest-green font-bold">{searchQuery}</span>"
                  </p>
                )}
              </div>
              
              <div className="flex flex-wrap items-center justify-center gap-4">
                <div className="flex items-center gap-2 bg-white px-4 py-2.5 rounded-2xl shadow-sm border border-gray-100">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Sort By:</span>
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="text-xs font-bold text-harvest-brown focus:outline-none bg-transparent cursor-pointer"
                  >
                    <option value="default">Featured</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                  </select>
                </div>

                <div className="bg-white px-4 py-2.5 rounded-2xl shadow-sm border border-gray-100">
                  <span className="text-harvest-brown font-black text-[10px] uppercase tracking-widest">
                    {filteredProducts.length} Machines Found
                  </span>
                </div>
              </div>
            </div>

            {/* Product Grid */}
            {sortedProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {sortedProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-24 bg-white rounded-[3rem] shadow-xl border border-gray-100">
                <div className="bg-harvest-cream w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search size={40} className="text-gray-300" />
                </div>
                <h3 className="text-2xl font-black text-harvest-brown mb-2">No Matching Machines</h3>
                <p className="text-gray-500 max-w-sm mx-auto font-medium">
                  We couldn't find any equipment matching your current filters. Try a different term or browse categories.
                </p>
                <button 
                  onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
                  className="mt-8 bg-harvest-green text-white px-10 py-4 rounded-xl font-black uppercase tracking-widest text-xs hover:scale-105 transition-transform"
                >
                  Clear all search filters
                </button>
              </div>
            )}
            
            {/* Pagination Mockup */}
            {filteredProducts.length > 0 && (
              <div className="mt-20 text-center">
                <button className="bg-white border-2 border-harvest-brown/10 text-harvest-brown px-12 py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-harvest-brown hover:text-white transition-all shadow-lg hover:-translate-y-1">
                  Load More Equipment
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Shop;