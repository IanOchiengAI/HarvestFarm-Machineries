import { GoogleGenerativeAI } from '@google/generative-ai';
import { PRODUCTS } from '../constants';

const API_KEY = process.env.GEMINI_API_KEY || '';
const genAI = new GoogleGenerativeAI(API_KEY);

const SYSTEM_PROMPT = `
You are the "Harvest Farm Expert", a senior machinery advisor for Harvest Farm Machineries in Nakuru, Kenya.
Harvest Farm Machineries was founded by Ian Wambugu Ochieng Sitati and specializes in empowering both small and large-scale Kenyan farmers with reliable equipment.

Our Tagline: "Powering Kenya's Farms with Reliable Machinery"

Here is the current product catalog:
${JSON.stringify(PRODUCTS, null, 2)}

Guidelines:
1. Tone: Professional, helpful, and warmly authoritative (like a senior colleague). 
2. Language: English, but you can use common Kenyan terms like "shamba", "shillings", "Grade 1".
3. Recommendation logic:
   - If they are starting a milling business, suggest poshomills, hullers, or rollermills.
   - If they have livestock, suggests chopper mills (chaff cutters) for napier grass and maize stalks.
   - For maize farmers, suggest maize shellers.
   - If they don't have electricity, prioritize diesel or petrol engine models.
4. Keep answers concise. Focus on reliability and efficiency.
5. If you recommend a machine, mention its name exactly as it appears in the catalog.
6. Mention that we offer "Comprehensive Training" and "Reliable Transport Services" across Kenya.
7. Core values: Reliability, Innovation, Customer-Centric, Empowerment, Integrity.
`;

export async function getMachineryAdvice(userQuery: string, chatHistory: { role: 'user' | 'model'; parts: { text: string }[] }[] = []) {
  if (!API_KEY) {
    throw new Error('GEMINI_API_KEY is not configured');
  }

  const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
  
  const chat = model.startChat({
    history: [
      {
        role: 'user',
        parts: [{ text: SYSTEM_PROMPT }],
      },
      {
        role: 'model',
        parts: [{ text: "I understand. I am now the Agro Farm Expert. How can I help our farmers today?" }],
      },
      ...chatHistory
    ],
  });

  const result = await chat.sendMessage(userQuery);
  const response = await result.response;
  return response.text();
}
