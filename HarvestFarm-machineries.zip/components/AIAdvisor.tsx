import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Loader2, Sparkles, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getMachineryAdvice } from '../services/aiService';

interface Message {
  role: 'user' | 'model';
  parts: { text: string }[];
}

const AIAdvisor: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      parts: [{ text: input }],
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // We pass the current message history to maintain context
      const responseText = await getMachineryAdvice(input, messages);
      const assistantMessage: Message = {
        role: 'model',
        parts: [{ text: responseText }],
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('AI Advisor Error:', error);
      const errorMessage: Message = {
        role: 'model',
        parts: [{ text: "Pole sana (Sorry), I'm having trouble connecting right now. Please try again or chat with our team on WhatsApp!" }],
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 left-6 z-[60]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 left-0 w-[350px] md:w-[400px] bg-white rounded-2xl shadow-2xl border border-harvest-green/20 overflow-hidden flex flex-col h-[500px]"
          >
            {/* Header */}
            <div className="bg-harvest-brown p-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="bg-harvest-green p-2 rounded-lg">
                  <Bot size={20} />
                </div>
                <div>
                  <h3 className="font-black text-xs uppercase tracking-widest leading-none">Harvest Expert</h3>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-2 h-2 bg-harvest-gold rounded-full animate-pulse" />
                    <span className="text-[9px] text-gray-300 font-bold uppercase tracking-tighter">Powered by Gemini</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="hover:bg-white/10 p-1 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div 
              ref={scrollRef}
              className="flex-grow overflow-y-auto p-4 space-y-4 bg-harvest-cream/30 scroll-smooth"
            >
              {messages.length === 0 && (
                <div className="text-center py-10 px-6">
                  <div className="bg-harvest-green/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="text-harvest-green" size={24} />
                  </div>
                  <h4 className="font-black text-harvest-brown mb-2 text-xl uppercase tracking-tight">Assisting Kenyan Farmers</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">
                    Hello! I'm the Harvest Farm Advisor. How can I help you choose the right machinery for your shamba today?
                  </p>
                  <div className="mt-6 flex flex-wrap gap-2 justify-center">
                    {["Posho mill startup?", "Best for dairy farm?", "Diesel vs Petrol?"].map((q) => (
                      <button 
                        key={q}
                        onClick={() => setInput(q)}
                        className="text-[10px] bg-white border border-gray-200 hover:border-harvest-green hover:text-harvest-green px-4 py-2 rounded-xl transition-all shadow-sm font-bold uppercase tracking-widest"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {messages.map((m, idx) => (
                <motion.div 
                  initial={{ opacity: 0, x: m.role === 'user' ? 10 : -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={idx} 
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center ${m.role === 'user' ? 'bg-indigo-600' : 'bg-harvest-brown text-harvest-gold'} shadow-lg`}>
                      {m.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                    </div>
                    <div className={`p-4 rounded-2xl text-sm leading-relaxed font-medium ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white border border-gray-100 text-gray-800 rounded-tl-none shadow-sm'}`}>
                      {m.parts[0].text}
                    </div>
                  </div>
                </motion.div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-gray-100 p-3 rounded-2xl shadow-sm">
                    <Loader2 size={18} className="animate-spin text-harvest-green" />
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-gray-100">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask Harvest Advisor..."
                  className="flex-grow bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-harvest-green font-medium"
                />
                <button 
                  disabled={isLoading || !input.trim()}
                  className="bg-harvest-green text-white p-3 rounded-xl hover:bg-green-700 disabled:opacity-50 transition-all shadow-xl active:scale-95"
                >
                  <Send size={20} />
                </button>
              </form>
              <p className="text-[10px] text-gray-400 mt-3 text-center uppercase font-black tracking-widest opacity-60">
                Harvest Farm Machineries • Nakuru
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.05, rotate: 5 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-harvest-brown text-harvest-gold w-16 h-16 rounded-2xl shadow-2xl flex items-center justify-center relative hover:bg-harvest-brown/90 transition-all border border-white/10"
      >
        {isOpen ? <X size={28} /> : <Bot size={32} />}
        {!isOpen && (
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 bg-harvest-green text-[10px] font-black px-2 py-0.5 rounded-full border-2 border-white uppercase"
          >
            AI
          </motion.div>
        )}
      </motion.button>
    </div>
  );
};

export default AIAdvisor;
