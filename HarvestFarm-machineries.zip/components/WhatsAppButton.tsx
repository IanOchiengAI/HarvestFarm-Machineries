import React from 'react';
import { MessageCircle } from 'lucide-react';
import { WHATSAPP_LINK } from '../constants';

const WhatsAppButton: React.FC = () => {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-[#25D366] text-white px-5 py-3 rounded-full shadow-lg hover:scale-105 transition-transform animate-bounce-slight"
    >
      <MessageCircle size={24} fill="white" />
      <span className="font-bold hidden sm:inline">Chat on WhatsApp</span>
    </a>
  );
};

export default WhatsAppButton;