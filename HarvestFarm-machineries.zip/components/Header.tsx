import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, ShoppingCart, Search } from 'lucide-react';
import { PHONE_NUMBER } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Shop Machines', path: '/shop' },
    { name: 'Services', path: '/services' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 bg-white shadow-md">
      {/* Top Bar */}
      <div className="bg-harvest-green text-white py-2 px-4 text-sm hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <p>📍 Nakuru, Kenya</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Phone size={14} /> {PHONE_NUMBER}
            </span>
            <span className="font-semibold bg-harvest-orange px-2 py-0.5 rounded text-xs uppercase italic tracking-wider">Powering Kenya's Farms</span>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
            <div className="bg-harvest-brown p-2 rounded-lg">
              <img 
                src="https://ais-pre-wyz3etm7sygptpjd5xsh3r-499708115297.europe-west2.run.app/Harvest_Farm_Machinery_Logo.jpeg" 
                alt="Harvest Farm Logo" 
                className="w-10 h-10 object-contain brightness-0 invert" 
                onError={(e) => {
                  // Fallback if image doesn't exist
                  (e.target as any).style.display = 'none';
                  (e.target as any).parentElement.innerHTML = '<span class="text-white font-bold text-xl">HF</span>';
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-gray-900 leading-none">Harvest Farm</span>
              <span className="text-[10px] text-harvest-green font-bold uppercase tracking-[0.2em] mt-1">Machineries</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-bold uppercase tracking-wider hover:text-harvest-green transition-colors ${isActive(link.path) ? 'text-harvest-green underline decoration-2 underline-offset-8' : 'text-gray-600'}`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <Link to="/shop" className="text-gray-600 hover:text-harvest-green">
              <Search size={22} />
            </Link>
            <div className="relative">
              <ShoppingCart size={22} className="text-gray-600" />
              <span className="absolute -top-2 -right-2 bg-harvest-orange text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">0</span>
            </div>
            <button
              className="md:hidden text-gray-900"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 absolute w-full shadow-lg">
          <div className="flex flex-col p-4 gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-gray-800 font-medium py-2 border-b border-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            <a href={`tel:${PHONE_NUMBER}`} className="flex items-center gap-2 text-harvest-green font-bold py-2">
              <Phone size={18} /> Call {PHONE_NUMBER}
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;