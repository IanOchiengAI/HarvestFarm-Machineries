import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { ArrowRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-xl transition-shadow border border-gray-100 overflow-hidden flex flex-col h-full group">
      <div className="relative h-56 overflow-hidden">
        {product.isBestSeller && (
          <span className="absolute top-2 left-2 bg-agro-orange text-white text-xs font-bold px-2 py-1 rounded z-10 shadow-sm">
            BEST SELLER
          </span>
        )}
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <p className="text-xs text-agro-green font-semibold uppercase tracking-wide mb-1">{product.category}</p>
        <h3 className="font-bold text-gray-900 text-lg mb-2 line-clamp-2">{product.name}</h3>
        <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-grow">{product.description}</p>
        
        <div className="mt-auto">
          <p className="text-agro-green font-bold text-xl mb-3">KSh {product.price.toLocaleString()}</p>
          <Link 
            to={`/product/${product.id}`}
            className="w-full block text-center bg-gray-900 text-white py-2.5 rounded-lg font-medium hover:bg-agro-green transition-colors flex items-center justify-center gap-2"
          >
            View Details <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;