import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, MapPin, Phone, Mail } from 'lucide-react';
import { PHONE_NUMBER, LOCATION_LINK } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-harvest-brown text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        {/* Brand */}
        <div>
          <h3 className="text-2xl font-bold mb-4">Harvest Farm <span className="text-harvest-gold underline decoration-harvest-green decoration-4 underline-offset-8">Machineries</span></h3>
          <p className="text-gray-300 mb-4 font-medium italic">
            "Powering Kenya's Farms with Reliable Machinery"
          </p>
          <p className="text-gray-400 text-sm mb-4">
            Founded by Ian Wambugu Ochieng Sitati, we empower farmers with high-quality equipment, training, and support.
          </p>
          <div className="flex gap-4">
            <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-harvest-green transition-colors">
              <Facebook size={20} />
            </a>
            <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-harvest-green transition-colors font-bold text-sm flex items-center justify-center w-9 h-9">
              TT
            </a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-lg font-bold mb-4 uppercase tracking-widest text-harvest-gold">Quick Links</h4>
          <ul className="space-y-2 text-gray-400">
            <li><Link to="/shop" className="hover:text-harvest-gold">All Equipment</Link></li>
            <li><Link to="/services" className="hover:text-harvest-gold">Our Mission</Link></li>
            <li><Link to="/contact" className="hover:text-harvest-gold">Contact Us</Link></li>
            <li><Link to="/shop" className="hover:text-harvest-gold">Posho Mills</Link></li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-lg font-bold mb-4 uppercase tracking-widest text-harvest-gold">Find Us</h4>
          <ul className="space-y-4 text-gray-400">
            <li className="flex items-start gap-3">
              <MapPin className="mt-1 text-harvest-gold" size={20} />
              <a href={LOCATION_LINK} target="_blank" rel="noreferrer" className="hover:text-white">
                Nakuru CBD, Kenya<br />Visit our Showroom
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Phone className="text-harvest-gold" size={20} />
              <a href={`tel:${PHONE_NUMBER}`} className="hover:text-white">{PHONE_NUMBER}</a>
            </li>
            <li className="flex items-center gap-3">
              <Mail className="text-harvest-gold" size={20} />
              <a href="mailto:info@harvestfarm.co.ke" className="hover:text-white">info@harvestfarm.co.ke</a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 pt-6 text-center text-gray-500 text-xs font-bold uppercase tracking-widest">
        <p>&copy; {new Date().getFullYear()} Harvest Farm Machineries. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;