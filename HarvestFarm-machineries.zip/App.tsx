import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import AIAdvisor from './components/AIAdvisor';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetail from './pages/ProductDetail';
import Services from './pages/Services';
import Contact from './pages/Contact';

const App: React.FC = () => {
  return (
    <Router>
      <div className="flex flex-col min-h-screen font-sans">
        <Helmet>
          <title>Harvest Farm Machineries | Reliable Farm Machines in Nakuru</title>
          <meta name="description" content="Shop reliable posho mills, hullers, and maize shellers in Nakuru, Kenya. Founded by Ian Wambugu Ochieng Sitati. Nationwide delivery and training." />
          <link rel="canonical" href="https://harvestfarmnk.co.ke" />
          <meta property="og:type" content="website" />
          <meta property="og:title" content="Harvest Farm Machineries - Kenya's Trusted Farm Equipment Partner" />
          <meta property="og:description" content="Quality agricultural machinery for Kenyan farmers. Visit Harvest Farm in Nakuru for posho mills, choppermills, and shellers." />
        </Helmet>
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <AIAdvisor />
        <WhatsAppButton />
        <Footer />
      </div>
    </Router>
  );
};

export default App;